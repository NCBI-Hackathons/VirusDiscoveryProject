
# coding: utf-8

# In[15]:


import numpy as np
import os
import pandas as pd
import sys


# In[27]:


filename=sys.argv[1]
file=open(filename, encoding="utf8")
line=file.readline()
contigs=[]
while True:
    data=line.strip("\n").split("\t")
    if data[0] not in contigs:
            contigs.append(data[0].split(":")[0])
    if data[1] not in contigs:
        contigs.append(data[1].split(":")[0])
    line=file.readline()
    if line is None or line=='':
                break


# In[30]:


file=open(filename, encoding="utf8")
line=file.readline()
dist=np.zeros([len(contigs),len(contigs)])
while True:
    data=line.strip("\n").split("\t")
    dist[contigs.index(data[0].split(":")[0]),contigs.index(data[1].split(":")[0])]=data[2]
    line=file.readline()
    if line is None or line=='':
                break


# In[31]:


dfMat = pd.DataFrame(dist, columns=contigs, index=contigs)


# In[32]:


dfMat.to_csv("distMat.csv",sep=";")

