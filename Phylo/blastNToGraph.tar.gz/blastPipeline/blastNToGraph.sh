#!/bin/bash

#USAGE: bash blastnToGraph.sh input_file.fasta e-value min_identity
#Resulrs are sent to the results directory, created in the directory were the scripts are.

in_file=$1
e_val=$2
min_iden=$3

#Blast Database creation.
makeblastdb -in $in_file -out blast_DB -dbtype nucl -input_type fasta

echo "DB Done"

#Blast of sequences against themselves.
blastn -query $in_file -db blast_DB -num_threads 96 -outfmt 7 -evalue $e_val -max_hsps 1 -perc_identity $min_iden -out results.blastn

echo "Blastn done"

#Adjustment of format of blast output.
python3 blast_pairs.py -i results.blastn -o blast_pairs.tsv

echo "File adjusted"

#Generation of distance matrix (for network creation).
python3 toMatrix.py blast_pairs.tsv

echo "matrix_Done"

mkdir results/
mv results.blastn results/
mv blast_pairs.tsv results/
mv distMat.csv results/
mv blast_DB* results/
